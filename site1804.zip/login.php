<?php
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    echo("E-Mail: $email <br> Senha: $senha");
?>