<?php
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    echo("Nome: $nome <br> E-Mail: $email <br> Senha: $senha");
?>